#include <stdio.h>

// Function to validate user input (y/n)
int validateInput(char answer) {
    return (answer == 'y' || answer == 'n' || answer == 'Y' || answer == 'N');
}

int main() {
    char answer;

    printf("\nWelcome to the recommendation generator! (created by @pruthvvii_)\n");
    printf("\nThe generator will recommend you suggestions for anime, movies, and books based on your answers.\n");
    printf("\nThe generator will ask you a few questions, and you can answer with (y = yes, n = no).\n");
    printf("\nAre you ready to answer the questions? (y/n): ");
    scanf(" %c", &answer);

    if (!validateInput(answer)) {
        printf("\nInvalid input. Please enter either 'y' or 'n'.\n");
        return 1; // Exit the program with error
    }

    if (answer == 'y' || answer == 'Y') {
        // Anime Recommendations

        // Action Anime
        printf("\nDo you like action anime? (y/n): ");
        scanf(" %c", &answer);

        if (answer == 'y' || answer == 'Y') {
            printf("\nHere are the following action anime recommendations:\n");
            printf("\n* Attack on Titan\n");
            printf("\n* One Punch Man\n");
            // Add more action anime recommendations here
            printf("\n--------------------------------------------\n");
        } 
        else if (answer == 'n' || answer == 'N') {
            // Comedy Anime
            printf("\nDo you like comedy anime? (y/n): ");
            scanf(" %c", &answer);

            if (answer == 'y' || answer == 'Y') {
                printf("\nHere are the following comedy anime recommendations:\n");
                printf("\n* Konosuba: God's Blessing on This Wonderful World!\n");
                printf("\n* Gintama\n");
                // Add more comedy anime recommendations here
                printf("\n--------------------------------------------\n");
            } 
            else if (answer == 'n' || answer == 'N') {
                // Mecha Anime
                printf("\nDo you like mecha anime? (y/n): ");
                scanf(" %c", &answer);

                if (answer == 'y' || answer == 'Y') {
                    printf("\nHere are the following mecha anime recommendations:\n");
                    printf("\n* Mobile Suit Gundam\n");
                    printf("\n* Code Geass\n");
                    // Add more mecha anime recommendations here
                    printf("\n--------------------------------------------\n");
                } 
                else if (answer == 'n' || answer == 'N') {
                    // Horror Anime/Manga
                    printf("\nDo you like horror anime or manga? (y/n): ");
                    scanf(" %c", &answer);

                    if (answer == 'y' || answer == 'Y') {
                        printf("\nHere are the following horror anime and manga recommendations:\n");
                        printf("\n* Another\n");
                        printf("\n* Tokyo Ghoul\n");
                        // Add more horror anime/manga recommendations here
                        printf("\n--------------------------------------------\n");
                    } 
                    else if (answer == 'n' || answer == 'N') {
                        // Provide generic anime recommendations
                        printf("\nSorry, we couldn't determine your preference.\n");
                        // Add more generic anime recommendations here
                        printf("\n--------------------------------------------\n");
                    } 
                    else {
                        printf("\nInvalid input. Please enter either 'y' or 'n'.\n");
                        return 1; // Exit the program with error
                    }
                } 
                else {
                    printf("\nInvalid input. Please enter either 'y' or 'n'.\n");
                    return 1; // Exit the program with error
                }
            } 
            else {
                printf("\nInvalid input. Please enter either 'y' or 'n'.\n");
                return 1; // Exit the program with error
            }
        } 
        else {
            printf("\nInvalid input. Please enter either 'y' or 'n'.\n");
            return 1; // Exit the program with error
        }

        // Movie Recommendations

        // Action Movies
        printf("\nDo you like action movies? (y/n): ");
        scanf(" %c", &answer);

        if (answer == 'y' || answer == 'Y') {
            printf("\nHere are the following action movie recommendations:\n");
            printf("\n* The Dark Knight\n");
            printf("\n* Mad Max: Fury Road\n");
            // Add more action movie recommendations here
            printf("\n--------------------------------------------\n");
        } 
        else if (answer == 'n' || answer == 'N') {
            // Comedy Movies
            printf("\nDo you like comedy movies? (y/n): ");
            scanf(" %c", &answer);

            if (answer == 'y' || answer == 'Y') {
                printf("\nHere are the following comedy movie recommendations:\n");
                printf("\n* Superbad\n");
                printf("\n* The Hangover\n");
                // Add more comedy movie recommendations here
                printf("\n--------------------------------------------\n");
            } 
            else if (answer == 'n' || answer == 'N') {
                // Sci-Fi/Fantasy Movies
                printf("\nDo you like Sci-Fi or Fantasy movies? (y/n): ");
                scanf(" %c", &answer);

                if (answer == 'y' || answer == 'Y') {
                    printf("\nHere are the following Sci-Fi/Fantasy movie recommendations:\n");
                    printf("\n* Star Wars series\n");
                    printf("\n* The Lord of the Rings\n");
                    // Add more Sci-Fi/Fantasy movie recommendations here
                    printf("\n--------------------------------------------\n");
                } 
                else if (answer == 'n' || answer == 'N') {
                    // Provide generic movie recommendations
                    printf("\nSorry, we couldn't determine your preference.\n");
                    // Add more generic movie recommendations here
                    printf("\n--------------------------------------------\n");
                } 
                else {
                    printf("\nInvalid input. Please enter either 'y' or 'n'.\n");
                    return 1; // Exit the program with error
                }
            } 
            else {
                printf("\nInvalid input. Please enter either 'y' or 'n'.\n");
                return 1; // Exit the program with error
            }
        } 
        else {
            printf("\nInvalid input. Please enter either 'y' or 'n'.\n");
            return 1; // Exit the program with error
        }

        // Book Recommendations

        // Mystery/Thriller Books
        printf("\nDo you like mystery/thriller books? (y/n): ");
        scanf(" %c", &answer);

        if (answer == 'y' || answer == 'Y') {
            printf("\nHere are the following mystery/thriller book recommendations:\n");
            printf("\n* The Girl with the Dragon Tattoo by Stieg Larsson\n");
			printf("\n* Gone Girl by Gillian Flynn\n");
// Add more mystery/thriller book recommendations here
		printf("\n--------------------------------------------\n");
	}
	else if (answer == 'n' || answer == 'N') {
// Fantasy Books
printf("\nDo you prefer fantasy books? (y/n): ");
scanf(" %c", &answer);


               if (answer == 'y' || answer == 'Y') {
            printf("\nHere are the following fantasy book recommendations:\n");
            printf("\n* Harry Potter series by J.K. Rowling\n");
            printf("\n* The Name of the Wind by Patrick Rothfuss\n");
            // Add more fantasy book recommendations here
            printf("\n--------------------------------------------\n");
        } 
        else if (answer == 'n' || answer == 'N') {
            // Provide generic book recommendations
            printf("\nSorry, we couldn't determine your preference.\n");
            // Add more generic book recommendations here
            printf("\n--------------------------------------------\n");
        } 
        else {
            printf("\nInvalid input. Please enter either 'y' or 'n'.\n");
            return 1; // Exit the program with error
        }
    } 
    else {
        printf("\nInvalid input. Please enter either 'y' or 'n'.\n");
        return 1; // Exit the program with error
    }

} 
else if (answer == 'n' || answer == 'N') {
    printf("\nOkay, feel free to return whenever you're ready. Have a great day!\n");
} 
else {
    printf("\nInvalid input. Please enter either 'y' or 'n'.\n");
    return 1; // Exit the program with error
}

printf("\n"); // Just to format output

return 0; // Exit the program successfully
}
